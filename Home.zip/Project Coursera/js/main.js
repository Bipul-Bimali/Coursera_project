function he(){
    var loca = document.getElementById('locate').value
    var li=document.createDocumentFragment()
    loca.split(",")
    var lat = loca[0]
    // alert(lat)
    var lon = loca[1]
    // alert(lon[0])
    document.querySelector(".forecast").style.display="flex";
    fetch(`http://www.7timer.info/bin/api.pl?lon=${lon}&lat=${lat}&product=civil&output=json`)
        .then((response)=>response.json())
        .then((data)=> doit(data))
        .catch(error=>{alert(error)

        })
    fetch(`http://www.7timer.info/bin/api.pl?lon=${lon}&lat=${lat}&product=two&output=json`)
        .then((response)=>response.json())
        .then((data)=>disp(data))
    // alert("here")
    // consoitle.log(a.json)
    // document.getElementById("forecast").innerHTML=aa
    // alert(loca)
}
function disp(data){
    var aa = data.dataseries[1].weather
    alert(aa)
}
function doit(data){
    // alert(data.dataseries[0].weather)
    var a = data.dataseries[0].cloudcover
    var b = data.dataseries[0].lifted_index
    var c = data.dataseries[0].prec_type
    var d = data.dataseries[0].prec_amount
    var e = data.dataseries[0].temp2m
    var f = data.dataseries[0].rh2m
    var g = data.dataseries[0].wind10m_direction
    var h = data.dataseries[0].wind10m_speed
    var i = data.dataseries[0].weather
    console.log(a)
    console.log(b)
    console.log(c)
    console.log(d)
    console.log(e)
    console.log(f)
    console.log(g)
    console.log(h)
    console.log(i)
    console.log("new")
    switch (i) {
            case "clearday":
                document.getElementById("day1").src="images/clear.png"
            break;
            case "clearnight":
                document.getElementById("day1").src="images/clear.png"
            break;
            case "pcloudyday":
                document.getElementById("day1").src="images/pcloudy.png"
            break;
            case "pcloudynight":
                document.getElementById("day1").src="images/pcloudy.png"
            break;
            case "mcloudynight":
                document.getElementById("day1").src="images/mcloudy.png"
            break;
            case "mcloudyday":
                document.getElementById("day1").src="images/mcloudy.png"
            break;
            case "cloudynight":
                document.getElementById("day1").src="images/cloudy.png"
            break;
            case "cloudyday":
                document.getElementById("day1").src="images/cloudy.png"
            break;
            case "humidday":
                document.getElementById("day1").src="images/humid.png"
            break;
            case "humidnight":
                document.getElementById("day1").src="images/humid.png"
            break;
            case "lightrainday":
                document.getElementById("day1").src="images/lightrain.png"
            break;
            
            case "lightrainnight":
                document.getElementById("day1").src="images/lightrain.png"
            break;
            case "oshowernight":
                document.getElementById("day1").src="images/oshower.png"
            break;
            
            case "oshowerday":
                document.getElementById("day1").src="images/oshower.png"
            break;
            case "ishowerday":
                document.getElementById("day1").src="images/ishower.png"
            break;
            case "ishowernight":
                document.getElementById("day1").src="images/ishower.png"
            break;
            case "lightsnowday":
                document.getElementById("day1").src="images/lightsnow.png"
            break;
            case "lightsnownight":
                document.getElementById("day1").src="images/lightsnow.png"
            break;
            case "rainsnownight":
                document.getElementById("day1").src="images/rainsnow.png"
            break;
            case "rainsnowday":
                document.getElementById("day1").src="images/rainsnow.png"
            break;
            case "tsday"||"tsnight":
                document.getElementById("day1").src="images/tstrom.png"
            break;
            case "tsrainday":
                document.getElementById("day1").src="images/tsrain.png"
            break;
            case "tsrainnight":
                document.getElementById("day1").src="images/tsrain.png"
            break;

        default:
            alert(i)
            break;
    }
    document.getElementById("max1").innerText = `max temp: ${e}`
    var relative_humidity =f
}
